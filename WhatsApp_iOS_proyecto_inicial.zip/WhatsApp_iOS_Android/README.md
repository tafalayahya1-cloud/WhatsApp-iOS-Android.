# WhatsApp iOS (independiente) — Android

Proyecto inicial de mensajería real para Android con interfaz inspirada en iOS. No es una aplicación oficial de WhatsApp ni se conecta a la red de WhatsApp.

## Antes de compilar

1. Crea un proyecto en Firebase Console.
2. Añade una aplicación Android con el identificador `com.example.whatsappios`.
3. Descarga `google-services.json` y colócalo dentro de la carpeta `app/`.
4. En Firebase Authentication, activa **Correo electrónico/contraseña**.
5. Crea una base de datos Cloud Firestore.
6. Publica las reglas de `firestore.rules`.

## Crear el APK sin Android Studio en el móvil

1. Sube el contenido de este proyecto a un repositorio GitHub.
2. Añade `app/google-services.json` (no compartas ese archivo públicamente si no quieres exponer la configuración de tu proyecto Firebase).
3. Abre la pestaña **Actions** y ejecuta **Build Android APK**.
4. Descarga el artefacto `WhatsApp-iOS-debug` cuando termine.

## Estado de esta versión

Incluye registro/inicio de sesión por correo, listado de usuarios registrados y mensajes de texto privados en tiempo real mediante Firebase. Es una base inicial: todavía no incluye envío de fotos, llamadas, estados, notificaciones push, cifrado de extremo a extremo ni sincronización de contactos. Antes de usarla con datos reales, hay que endurecer las reglas de Firestore para validar que solo los dos participantes de cada conversación puedan leer y escribir.
