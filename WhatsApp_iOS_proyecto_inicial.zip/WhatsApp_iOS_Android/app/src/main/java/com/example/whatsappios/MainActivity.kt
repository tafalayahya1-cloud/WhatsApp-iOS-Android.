package com.example.whatsappios

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import java.security.MessageDigest

private val Green = Color(0xFF22C875)
private val Ink = Color(0xFF101114)
private val Muted = Color(0xFF8B9098)
private val Page = Color(0xFFF5F6F8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ChatApp() }
    }
}

data class ChatUser(val uid: String = "", val name: String = "", val email: String = "")
data class ChatMessage(val id: String = "", val senderId: String = "", val text: String = "", val createdAt: Long = 0)

@Composable
fun ChatApp() {
    val auth = remember { FirebaseAuth.getInstance() }
    var currentUser by remember { mutableStateOf(auth.currentUser) }
    var selected by remember { mutableStateOf<ChatUser?>(null) }
    MaterialTheme(colorScheme = lightColorScheme(primary = Green, background = Page)) {
        Surface(Modifier.fillMaxSize(), color = Page) {
            if (currentUser == null) {
                AuthScreen(
                    onAuth = { email, password, name, register ->
                        if (register) {
                            auth.createUserWithEmailAndPassword(email, password)
                                .addOnSuccessListener { result ->
                                    val u = result.user ?: return@addOnSuccessListener
                                    FirebaseFirestore.getInstance().collection("users").document(u.uid)
                                        .set(mapOf("uid" to u.uid, "name" to name, "email" to email))
                                    currentUser = u
                                }
                        } else {
                            auth.signInWithEmailAndPassword(email, password)
                                .addOnSuccessListener { currentUser = it.user }
                        }
                    }
                )
            } else if (selected == null) {
                PeopleScreen(
                    myUid = currentUser!!.uid,
                    onSelect = { selected = it },
                    onLogout = { auth.signOut(); currentUser = null }
                )
            } else {
                DirectChatScreen(
                    me = currentUser!!.uid,
                    other = selected!!,
                    onBack = { selected = null }
                )
            }
        }
    }
}

@Composable
fun AuthScreen(onAuth: (String, String, String, Boolean) -> Unit) {
    var register by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(26.dp), verticalArrangement = Arrangement.Center) {
        Text("WhatsApp", fontSize = 35.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("estilo iOS · mensajería independiente", color = Muted)
        Spacer(Modifier.height(28.dp))
        if (register) OutlinedTextField(name, { name = it }, label = { Text("Nombre") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(email, { email = it }, label = { Text("Correo electrónico") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(password, { password = it }, label = { Text("Contraseña") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        if (error.isNotBlank()) Text(error, color = Color.Red)
        Spacer(Modifier.height(12.dp))
        Button(onClick = {
            error = ""
            if (email.isBlank() || password.length < 6 || (register && name.isBlank())) error = "Completa los campos. La contraseña debe tener 6 caracteres."
            else onAuth(email.trim(), password, name.trim(), register)
        }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) {
            Text(if (register) "Crear cuenta" else "Iniciar sesión", color = Color.White)
        }
        TextButton(onClick = { register = !register }) {
            Text(if (register) "Ya tengo una cuenta" else "Crear una cuenta")
        }
    }
}

@Composable
fun PeopleScreen(myUid: String, onSelect: (ChatUser) -> Unit, onLogout: () -> Unit) {
    var people by remember { mutableStateOf<List<ChatUser>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    DisposableEffect(myUid) {
        val reg = FirebaseFirestore.getInstance().collection("users").addSnapshotListener { snap, _ ->
            people = snap?.documents?.mapNotNull { d ->
                val u = d.toObject(ChatUser::class.java)
                if (u != null && u.uid != myUid) u else null
            } ?: emptyList()
            loading = false
        }
        onDispose { reg.remove() }
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Color.White).padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Chats", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text("Personas registradas", color = Muted, fontSize = 13.sp)
            }
            IconButton(onClick = onLogout) { Icon(Icons.Default.Logout, "Cerrar sesión") }
        }
        if (loading) CircularProgressIndicator(Modifier.align(Alignment.CenterHorizontally).padding(25.dp))
        else if (people.isEmpty()) Text("Aún no hay otros usuarios. Registra otra cuenta para probar chats.", Modifier.padding(22.dp), color = Muted)
        LazyColumn {
            items(people, key = { it.uid }) { person ->
                Row(Modifier.fillMaxWidth().clickable { onSelect(person) }.padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp).background(Green.copy(alpha = .16f), CircleShape), contentAlignment = Alignment.Center) {
                        Text(person.name.take(1).uppercase(), color = Green, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    }
                    Spacer(Modifier.width(13.dp))
                    Column {
                        Text(person.name, color = Ink, fontWeight = FontWeight.SemiBold)
                        Text(person.email, color = Muted, fontSize = 13.sp)
                    }
                }
                HorizontalDivider(color = Color(0xFFE8E9ED))
            }
        }
    }
}

@Composable
fun DirectChatScreen(me: String, other: ChatUser, onBack: () -> Unit) {
    val db = remember { FirebaseFirestore.getInstance() }
    val chatId = remember(me, other.uid) { sha256(listOf(me, other.uid).sorted().joinToString("_")) }
    var messages by remember { mutableStateOf<List<ChatMessage>>(emptyList()) }
    var draft by remember { mutableStateOf("") }
    DisposableEffect(chatId) {
        val reg = db.collection("chats").document(chatId).collection("messages")
            .orderBy("createdAt", Query.Direction.ASCENDING)
            .addSnapshotListener { snap, _ ->
                messages = snap?.documents?.mapNotNull { it.toObject(ChatMessage::class.java)?.copy(id = it.id) } ?: emptyList()
            }
        onDispose { reg.remove() }
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 8.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Volver") }
            Column(Modifier.weight(1f)) {
                Text(other.name, fontWeight = FontWeight.Bold, color = Ink, fontSize = 17.sp)
                Text("chat privado", color = Muted, fontSize = 12.sp)
            }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp), contentPadding = PaddingValues(vertical = 14.dp)) {
            items(messages, key = { it.id }) { msg ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.senderId == me) Arrangement.End else Arrangement.Start) {
                    Surface(color = if (msg.senderId == me) Color(0xFFD8F8E5) else Color.White, shape = RoundedCornerShape(18.dp), shadowElevation = 1.dp, modifier = Modifier.padding(vertical = 4.dp).widthIn(max = 290.dp)) {
                        Text(msg.text, Modifier.padding(horizontal = 14.dp, vertical = 10.dp), color = Ink)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().background(Color.White).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(draft, { draft = it }, modifier = Modifier.weight(1f), placeholder = { Text("Mensaje") }, shape = RoundedCornerShape(24.dp), maxLines = 4)
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = {
                val value = draft.trim()
                if (value.isNotEmpty()) {
                    val ref = db.collection("chats").document(chatId).collection("messages").document()
                    db.collection("chats").document(chatId)
                        .set(mapOf("participants" to listOf(me, other.uid)))
                        .addOnSuccessListener {
                            ref.set(mapOf("id" to ref.id, "senderId" to me, "text" to value, "createdAt" to System.currentTimeMillis()))
                        }
                    draft = ""
                }
            }, enabled = draft.isNotBlank()) {
                Icon(Icons.Default.Send, "Enviar", tint = Green)
            }
        }
    }
}

fun sha256(value: String): String {
    val bytes = MessageDigest.getInstance("SHA-256").digest(value.toByteArray())
    return bytes.joinToString("") { "%02x".format(it) }
}
